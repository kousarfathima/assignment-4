﻿using System;
using System.Collections.Generic;

class Program {
    static void Main(string[] args) {
        List<string> names = new List<string> { "John", "Mary", "John", "Steve", "Mary", "Mary" };
        Dictionary<string, int> counts = new Dictionary<string, int>();

        foreach (string name in names) {
            if (counts.ContainsKey(name)) {
                counts[name]++;
            } else {
                counts[name] = 1;
            }
        }

        foreach (KeyValuePair<string, int> pair in counts) {
            Console.WriteLine("{0}: {1}", pair.Key, pair.Value);
        }
    }
}
