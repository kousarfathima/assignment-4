﻿using System;

public static class StringExtensions
{
    public static int CountVowels(this string str)
    {
        int count = 0;
        foreach (char c in str.ToLower())
        {
            if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u')
            {
                count++;
            }
        }
        return count;
    }
}

public class Program
{
    public static void Main()
    {
        Console.Write("Enter a string: ");
        string input = Console.ReadLine();

        int vowelCount = input.CountVowels();
        Console.WriteLine("The string '{0}' contains {1} vowels.", input, vowelCount);
    }
}
